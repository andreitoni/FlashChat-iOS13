//
//  Message.swift
//  Flash Chat iOS13
//
//  Created by Andrei Toni Niculae on 30.04.2024.
//  Copyright © 2024 Angela Yu. All rights reserved.
//

import Foundation

struct Message {
    let sender: String //email address of the sender
    let body: String
}
